<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
    <context>
        <name>behavior_1/behavior.xar:/Diagram/Say</name>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>there is nothing here</source>
            <comment>Text</comment>
            <translation type="unfinished">there is nothing here</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Say</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">Hello</translation>
        </message>
        <message>
            <source>i see raymond</source>
            <comment>Text</comment>
            <translation type="obsolete">i see raymond</translation>
        </message>
        <message>
            <source>I see a Sun Kiss can</source>
            <comment>Text</comment>
            <translation type="obsolete">I see a Sun Kiss can</translation>
        </message>
        <message>
            <source>I see a Sun Kiss Can</source>
            <comment>Text</comment>
            <translation type="obsolete">I see a Sun Kiss Can</translation>
        </message>
        <message>
            <source>i see sun kiss </source>
            <comment>Text</comment>
            <translation type="obsolete">i see sun kiss </translation>
        </message>
        <message>
            <source>there is nothing here</source>
            <comment>Text</comment>
            <translation type="obsolete">there is nothing here</translation>
        </message>
        <message>
            <source>Picture Taken</source>
            <comment>Text</comment>
            <translation type="obsolete">Picture Taken</translation>
        </message>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>done</source>
            <comment>Text</comment>
            <translation type="unfinished">done</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Say (1)</name>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>there is nothing here</source>
            <comment>Text</comment>
            <translation type="unfinished">there is nothing here</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Say (2)</name>
        <message>
            <source>there is nothing here</source>
            <comment>Text</comment>
            <translation type="obsolete">there is nothing here</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Vision Reco./Vision Reco./Say</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">Hello</translation>
        </message>
        <message>
            <source>email sent</source>
            <comment>Text</comment>
            <translation type="obsolete">email sent</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Vision Reco./Vision Reco./Say (1)</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">Hello</translation>
        </message>
    </context>
</TS>
